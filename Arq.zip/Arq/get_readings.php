<?php
$hostname = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "db_arq"; 

$conn = mysqli_connect($hostname, $username, $password, $database);
$response=[];
if (!$conn) { 
	die("Connection failed: " . mysqli_connect_error()); 
} 
else{
echo "Database connection is OK<br>"; 

$sql="SELECT * FROM readings ORDER BY id DESC LIMIT 1";
$result=mysqli_query($conn,$sql);
if($result){
    header("content-Type: JSON");
    $i=0;
    while($row=mysqli_fetch_assoc($result)){
        $response[$i]['id']=$row['id'];
        $response[$i]['temp']=$row['temperature'];
        $response[$i]['tds']=$row['tds'];
        $response[$i]['ph']=$row['ph'];
        $i++;
    }
    echo json_encode($response,JSON_PRETTY_PRINT);
}


}

?>