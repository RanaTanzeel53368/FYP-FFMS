<?php

$hostname = "localhost"; 
$username = "root"; 
$password = ""; 
$database = "db_arq"; 

$conn = mysqli_connect($hostname, $username, $password, $database);

if (!$conn) { 
	die("Connection failed: " . mysqli_connect_error()); 
} 

echo "Database connection is OK<br>"; 

if(isset($_POST["temperature"]) && isset($_POST["tds"]) && isset($_POST["ph"])  ) {

	$temp = $_POST["temperature"];
	$tds = $_POST["tds"];
    $ph = $_POST["ph"];

	$sql = "INSERT INTO readings (temperature, tds) VALUES (".$temp.", ".$tds.",".$ph.")"; 

	if (mysqli_query($conn, $sql)) { 
		echo "\nNew record created successfully"; 
	} else { 
		echo "Error: " . $sql . "<br>" . mysqli_error($conn); 
	}
}

?>